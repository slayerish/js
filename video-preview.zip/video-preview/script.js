console.log("page loaded...");

function play(e) {
    e.play()
}

function pause(e) {
    e.pause()
}